## project dependency

**The development platform is on Linux, so the following instructions need to do some adaptation for windows**

This project depends on JUnit(4.12) library for TestCase, so the following steps assumes 
the path of JUnit is satisfied as 

    >$ export JUNIT_PATH="$HOME/libs/*"

## Instructions to compile the source

    >$ unzip mars_rovers.zip -d mars_rovers
    >$ cd mars_rovers

    >$ mkdir dist
    >$ javac -cp .:$JUNIT_PATH -d dist $(find ./src/* -iname "*.java")

## Instructions to run test
    
    >$ java -cp ./dist:$JUNIT_PATH org.junit.runner.JUnitCore mars_rovers.test.MarsRoversTest

## Instructions to run project with different input text data in current directory
   
    >$ java -cp ./dist mars_rovers.main.Controller [filename=test_feed.txt]
    >$ java -cp ./dist mars_rovers.main.Controller empty_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller invalid_plateau_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller invalid_rover_command_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller invalid_rover_deploy_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller invalid_rover_deploy_direction_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller lack_plateau_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller lack_rover_deploy_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller overbound_rover_deploy_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller overbound_rover_moveforward_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller over_plateau_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller over_rover_deploy_dimension_feed.txt
    >$ java -cp ./dist mars_rovers.main.Controller valid_feed.txt

**don't need JUnit library to run the program, so only use "./dist" as classpath**

    





    

    
    





