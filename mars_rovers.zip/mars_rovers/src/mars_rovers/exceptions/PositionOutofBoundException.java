package mars_rovers.exceptions;

public class PositionOutofBoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public PositionOutofBoundException() {
		super();
	}

	public PositionOutofBoundException(String message) {
		super(message);
	}

}
