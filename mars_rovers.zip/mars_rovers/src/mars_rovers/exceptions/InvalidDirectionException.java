package mars_rovers.exceptions;

public class InvalidDirectionException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidDirectionException() {
		super();
	}

	public InvalidDirectionException(String message) {
		super(message);
	}

}
