package mars_rovers.exceptions;

public class InputDataFormatException extends Exception {

	private static final long serialVersionUID = 1L;

	public InputDataFormatException() {
		super();
	}

	public InputDataFormatException(String message) {
		super(message);
	}

}
