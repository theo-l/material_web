package mars_rovers.exceptions;

public class MoveForwardException extends Exception {

	private static final long serialVersionUID = 1L;

	public MoveForwardException() {
		super();
	}

	public MoveForwardException(String message) {
		super(message);
	}

}
