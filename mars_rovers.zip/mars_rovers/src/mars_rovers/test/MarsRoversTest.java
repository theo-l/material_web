package mars_rovers.test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import mars_rovers.enums.Direction;
import mars_rovers.exceptions.InputDataFormatException;
import mars_rovers.exceptions.InvalidCommandException;
import mars_rovers.exceptions.InvalidDirectionException;
import mars_rovers.exceptions.MoveForwardException;
import mars_rovers.exceptions.PositionOutofBoundException;
import mars_rovers.main.Controller;
import mars_rovers.main.RobotRover;
import junit.framework.TestCase;

public class MarsRoversTest extends TestCase {

	private Controller ctr = null;
	private int lineNo = 0;

	/**
	 * Test empty input data validation
	 */
	public void testEmptyInputData() {
		ctr = new Controller();
		String[] testFeeds = {};
		for (String feed : testFeeds) {
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| InvalidCommandException | PositionOutofBoundException e) {
				assertNull(e);
			}
		}
		try {
			ctr.run();
		} catch (InputDataFormatException | MoveForwardException e) {
			assertTrue(e.getMessage()
					.equals(Controller.EMPTY_INPUTDATA_MESSAGE));
		}
	}

	/**
	 * Test lack dimension of Plateau size definition
	 */
	public void testLackPlateauSize() {
		String[] testFeeds = { "5 " };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.PLATEAUSIZE_DATA_NOT_ENOUGH_MESSAGE,
												lineNo, feed)));
			}

			lineNo++;
		}
	}

	/**
	 * Test too much dimension of Plateau size definition
	 */
	public void testOverPlateauSizeData() {
		String[] testFeeds = { "5 5 6" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.PLATEAUSZIE_DATA_OVER_MESSAGE,
												lineNo, feed)));
			}
			lineNo++;

		}
	}

	/**
	 * Test invalid value of Plateau size definition
	 */
	public void testInvalidPlateauSizeData() {
		String[] testFeeds = { "5 a" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										Controller.NONE_DIGIT_VALUE_MESSAGE,
										lineNo, "a")));
			}
			lineNo++;
		}

	}

	/**
	 * Test lack dimension of Rover deploy definition
	 */
	public void testLackRoverDeployData() {
		String[] testFeeds = { "5 5", "1" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.ROVER_DEPLOY_DATA_NOT_ENOUGH_MESSAGE,
												lineNo, feed)));
			}
			lineNo++;
		}
	}

	/**
	 * Test too much dimension of Rover deploy definition
	 */
	public void testOverRoverDeployData() {
		String[] testFeeds = { "5 5", "1 2 N W" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();

			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.ROVER_DEPLOY_DATA_OVER_MESSAGE,
												lineNo, feed)));
			}

			lineNo++;
		}
	}

	/**
	 * Test invalid data of Rover deploy definition
	 * 
	 */
	public void testInvalidRoverDeployData() {

		String[] testFeeds = { "5 5", "A 2 N" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										Controller.NONE_DIGIT_VALUE_MESSAGE,
										lineNo, "A")));
			}
			lineNo++;
		}
		ctr = new Controller();
		lineNo = 1;
		String[] testFeeds2 = { "5 5", "1 B E" };
		for (String feed : testFeeds2) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										Controller.NONE_DIGIT_VALUE_MESSAGE,
										lineNo, "B")));
			}
			lineNo++;
		}
		ctr = new Controller();
		lineNo = 1;
		String[] testFeeds3 = { "5 5", "1 2 A" };

		for (String feed : testFeeds3) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.INVALID_DIRECTION_VALUE_MESSAGE,
												lineNo, "A")));
			}
			lineNo++;
		}
	}

	/**
	 * Test over bound data of Rover deploy definition
	 */
	public void testOverBoundRoverDeployData() {

		String[] testFeeds = { "5 5", "1 6 N" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.ROVER_DEPLOY_POSITION_OVER_BOUND_MESSAGE,
												lineNo, 1, 6, 5, 5)));
			}
			lineNo++;
		}

	}

	/**
	 * Test invalid command of Rover
	 */
	public void testInvalidCommandData() {

		String[] testFeeds = { "5 5", "1 2 N", "LRMLLAB" };
		ctr = new Controller();
		lineNo = 1;
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage()
								.equals(String
										.format(Controller.INVALID_COMMAND_VALUE_MESSAGE,
												lineNo, feed)));
			}
			lineNo++;

		}
	}

	/**
	 * Test move forward over bound
	 */
	public void testMoveForwardToomuchData() {

		String[] testFeeds = { "5 5", "1 2 N", "MMMM" }; // too north
		ctr = new Controller();
		for (String feed : testFeeds) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										RobotRover.MOVEFORWARD_WARNING_MESSAGE,
										0, Direction.N.description(), feed)));
			}
		}
		String[] testFeeds2 = { "5 5", "1 2 N", "RMMMMM" };// too east
		ctr = new Controller();
		for (String feed : testFeeds2) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										RobotRover.MOVEFORWARD_WARNING_MESSAGE,
										0, Direction.E.description(), feed)));
			}

		}
		String[] testFeeds3 = { "5 5", "1 2 N", "RRMMMMM" };// too south
		ctr = new Controller();
		for (String feed : testFeeds3) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										RobotRover.MOVEFORWARD_WARNING_MESSAGE,
										0, Direction.S.description(), feed)));
			}
		}
		String[] testFeeds4 = { "5 5", "1 2 N", "RRRRMMMMM" };// too west
		ctr = new Controller();
		for (String feed : testFeeds4) {
			feed = feed.trim();
			try {
				ctr.readCommandFromString(feed);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertTrue(
						e.getMessage(),
						e.getMessage().equals(
								String.format(
										RobotRover.MOVEFORWARD_WARNING_MESSAGE,
										0, Direction.W.description(), feed)));
			}

		}
	}

	/**
	 * Using valid String data to test the correctness
	 */
	public void testValidStringInputData() {
		String[] validFeedDatas = { "5 5", "1 2 N", "LMLMLMLMM", "3 3 E ",
				"MMRMMRMRRM" };
		ctr = new Controller();
		for (String line : validFeedDatas) {
			line = line.trim();
			try {
				ctr.readCommandFromString(line);
			} catch (InputDataFormatException | InvalidDirectionException
					| PositionOutofBoundException | InvalidCommandException e) {
				assertNull(e);
			}
		}

		try {
			ctr.run();
		} catch (InputDataFormatException | MoveForwardException e) {
			assertNull(e);
		}

		String successResults = "Rover 1: (1 2 N) -[LMLMLMLMM]-> (1 3 N)\nRover 2: (3 3 E) -[MMRMMRMRRM]-> (5 1 E)\n";
		assertEquals(successResults, ctr.feedBack());

	}

	/**
	 * Using valid File data to test the correctness
	 */
	public void testValidFileInputData() {

		File file = Paths.get("valid_feed.txt").toFile();
		String filename = file.getAbsolutePath();
		ctr = new Controller();
		try {
			ctr.readCommandFromFile(filename);
			ctr.run();
		} catch (InputDataFormatException | InvalidDirectionException
				| PositionOutofBoundException | IOException
				| InvalidCommandException | MoveForwardException e) {
			assertNull(e);
		}

		String successResults = "Rover 1: (1 2 N) -[LMLMLMLMM]-> (1 3 N)\nRover 2: (3 3 E) -[MMRMMRMRRM]-> (5 1 E)\n";
		assertEquals(successResults, ctr.feedBack());

	}

}
