package mars_rovers.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import mars_rovers.enums.Command;
import mars_rovers.enums.Direction;
import mars_rovers.exceptions.InputDataFormatException;
import mars_rovers.exceptions.InvalidCommandException;
import mars_rovers.exceptions.InvalidDirectionException;
import mars_rovers.exceptions.MoveForwardException;
import mars_rovers.exceptions.PositionOutofBoundException;

public class Controller {

	public static final String EMPTY_INPUTDATA_MESSAGE = "Empty input data!";
	public static final String PLATEAUSIZE_DATA_NOT_ENOUGH_MESSAGE = "Plateau size data is not enough! Line %d: {%s}";
	public static final String PLATEAUSZIE_DATA_OVER_MESSAGE = "Plateau size data is over! Line %d: {%s}";
	public static final String ROVER_DEPLOY_DATA_NOT_ENOUGH_MESSAGE = "Rover deploy data is not enough! Line %d: {%s}";
	public static final String ROVER_DEPLOY_DATA_OVER_MESSAGE = "Rover deploy data is over! Line %d: {%s}";
	public static final String ROVER_DEPLOY_POSITION_OVER_BOUND_MESSAGE = "Line %d: Deploy Position (%d, %d) is over bound of Plateau size (%d, %d)";
	public static final String NONE_DIGIT_VALUE_MESSAGE = "Line %d: {%s} is not a valid digit value";
	public static final String INVALID_DIRECTION_VALUE_MESSAGE = "Line %d: {%s} is not a valid Direction value!";
	public static final String INVALID_COMMAND_VALUE_MESSAGE = "Line %d: Command {%s} contains invalid command value!";

	private int feedLineNumber = 0;
	private int realLineNumber = 1;
	private int width;
	private int heigh;
	private List<RobotRover> robotRovers = new ArrayList<RobotRover>();
	private RobotRover currentRobotRover = null;
	private int roverCount = 1;

	public Controller() {

	}

	public Controller(int width, int heigh) {
		this.width = width;
		this.heigh = heigh;
	}

	/**
	 * read all instructions by using a string filename
	 */
	public void readCommandFromFile(String filename)
			throws InputDataFormatException, InvalidDirectionException,
			PositionOutofBoundException, IOException, InvalidCommandException {
		FileReader fr = new FileReader(filename);
		readCommandFromFileReader(fr);

	}

	/**
	 * read all instructions by using a file object
	 */
	public void readCommandFromFile(File file) throws FileNotFoundException,
			InputDataFormatException, InvalidDirectionException,
			PositionOutofBoundException, IOException, InvalidCommandException {
		readCommandFromFileReader(new FileReader(file));
	}

	/**
	 * control each rover in the controller to execute their motion command
	 * serialized order
	 * @throws MoveForwardException 
	 */
	public void run() throws InputDataFormatException, MoveForwardException {

		if (feedLineNumber == 0) {
			throw new InputDataFormatException(EMPTY_INPUTDATA_MESSAGE);
		}

		for (RobotRover robotRover : robotRovers) {
				robotRover.runCommand();
		}

	}

	/**
	 * return the result after each rover executed their command
	 * 
	 * @return Each rover's position change
	 */
	public String feedBack() {
		StringBuilder sb = new StringBuilder();
		for (RobotRover robotRover : robotRovers) {
			sb.append(robotRover.toString());
		}
		return sb.toString();
	}

	/**
	 * read all instruction data from a reader object
	 *
	 */
	private void readCommandFromFileReader(Reader reader)
			throws InputDataFormatException, InvalidDirectionException,
			PositionOutofBoundException, IOException, InvalidCommandException {
		BufferedReader br = new BufferedReader(reader);

		String line = br.readLine();
		while (line != null) {
			line = line.trim();
			readCommandFromString(line);
			line = br.readLine();
		}

	}

	/**
	 * read each instruction line and parse it
	 */
	public void readCommandFromString(String command)
			throws InputDataFormatException, InvalidDirectionException,
			PositionOutofBoundException, InvalidCommandException {

		if (command.isEmpty() || command.startsWith("#")) {
			realLineNumber++;
			return;
		}

		if (feedLineNumber == 0) {
			readPlateauSizeLine(command);
			realLineNumber++;
			feedLineNumber++;
			return;
		}

		// deploy rover position
		if (feedLineNumber % 2 == 1) {
			readRoverPositionLine(command);
			realLineNumber++;
			feedLineNumber++;
			return;
		}
		// command for current rover
		else {
			readRoverCommandLine(command);
			realLineNumber++;
			feedLineNumber++;
			return;
		}

	}

	/**
	 * parse plateau size definition data line
	 */
	private void readPlateauSizeLine(String line)
			throws InputDataFormatException {
		String[] size = line.split(" ");
		if (size.length < 2) {
			throw new InputDataFormatException(String.format(
					PLATEAUSIZE_DATA_NOT_ENOUGH_MESSAGE, realLineNumber, line));
		} else if (size.length > 2) {
			throw new InputDataFormatException(String.format(
					PLATEAUSZIE_DATA_OVER_MESSAGE, realLineNumber, line));
		}

		width = validateDigit(size[0]);
		heigh = validateDigit(size[1]);

	}

	/**
	 * parse rover deploy definition data line
	 */
	private void readRoverPositionLine(String line)
			throws InputDataFormatException, InvalidDirectionException,
			PositionOutofBoundException {
		String[] position = line.split(" ");
		if (position.length < 3) {
			throw new InputDataFormatException(String.format(
					ROVER_DEPLOY_DATA_NOT_ENOUGH_MESSAGE, realLineNumber, line));
		} else if (position.length > 3) {
			throw new InputDataFormatException(String.format(
					ROVER_DEPLOY_DATA_OVER_MESSAGE, realLineNumber, line));
		}

		int x = validateDigit(position[0]);
		int y = validateDigit(position[1]);

		// check robot rover deploy position
		if (x > width || y > heigh) {
			throw new PositionOutofBoundException(String.format(
					ROVER_DEPLOY_POSITION_OVER_BOUND_MESSAGE, realLineNumber,
					x, y, width, heigh));
		}

		if (!Direction.validateDirectionValue(position[2])) {

			throw new InvalidDirectionException(String.format(
					INVALID_DIRECTION_VALUE_MESSAGE, realLineNumber,
					position[2]));

		}
		Direction direction = Direction.valueOf(position[2]);
		RobotRover rr = new RobotRover(x, y, width, heigh, direction,
				roverCount);
		currentRobotRover = rr;
		robotRovers.add(rr);
		roverCount++;

	}

	/**
	 * parse rover command data line
	 */
	private void readRoverCommandLine(String line)
			throws InvalidCommandException {
		if (!Command.validateCommandLine(line)) {
			throw new InvalidCommandException(String.format(
					INVALID_COMMAND_VALUE_MESSAGE, realLineNumber, line));
		}

		currentRobotRover.readCommand(line);
	}

	/**
	 * validator to valid digit number value
	 */
	private int validateDigit(String value) throws InputDataFormatException {
		if (value.matches("\\d+")) {
			return Integer.valueOf(value);
		} else {
			throw new InputDataFormatException(String.format(
					NONE_DIGIT_VALUE_MESSAGE, realLineNumber, value));
		}
	}

	public static void main(String[] args) {
		String filename = "test_feed.txt";
		if (args.length > 0) {
			filename = args[0];
		}
		String filepath = Paths.get(filename).toAbsolutePath().toString();
		Controller ctr = new Controller();
		try {
			ctr.readCommandFromFile(filepath);
			ctr.run();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		System.out.println(ctr.feedBack());

	}
}
