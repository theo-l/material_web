package mars_rovers.main;

import mars_rovers.enums.Command;
import mars_rovers.enums.Direction;
import mars_rovers.exceptions.MoveForwardException;

public class RobotRover {

	public static final String MOVEFORWARD_WARNING_MESSAGE = "Rover %d: Can not forward to <%s> anymore! Check command:{%s} please!";

	private int width;
	private int heigh;
	private int x0;
	private int y0;
	private Direction direction0;
	private int x;
	private int y;
	private Direction direction;
	private String command;
	private int id;
	private boolean isNormal = true;

	public RobotRover(int x, int y, int width, int heigh, Direction direction,
			int id) {
		this.x0 = this.x = x;
		this.y0 = this.y = y;
		this.width = width;
		this.heigh = heigh;
		this.direction0 = this.direction = direction;
		this.id = id;
	}

	public void readCommand(String command) {

		this.command = command;
	}

	/**
	 * execute current command serial
	 * 
	 * @throws MoveForwardException
	 */
	public void runCommand() throws MoveForwardException {
		if (command == null) {
			return;
		}

		for (int i = 0; i < command.length(); i++) {
			Command cmd = Command.valueOf(command.substring(i, i + 1));
			switch (cmd) {
			case L:
				turnLeft();
				break;
			case R:
				turnRight();
				break;
			case M:
				moveForward();
				break;
			}
		}
	}

	/**
	 * Turn rover's current direction to left
	 */
	public void turnLeft() {
		switch (this.direction) {
		case N:
			direction = Direction.W;
			break;
		case W:
			direction = Direction.S;
			break;
		case S:
			direction = Direction.E;
			break;
		case E:
			direction = Direction.N;
			break;

		default:
			break;
		}
	}

	/**
	 * Turn rover's current direction to right
	 */
	public void turnRight() {
		switch (this.direction) {
		case N:
			direction = Direction.E;
			break;
		case E:
			direction = Direction.S;
			break;
		case S:
			direction = Direction.W;
			break;
		case W:
			direction = Direction.N;
			break;

		default:
			break;
		}

	}

	/**
	 * Move 1 step forward in current direction
	 * 
	 * @throws MoveForwardException
	 */
	public void moveForward() throws MoveForwardException {

		switch (this.direction) {
		case N:
			if (this.y + 1 <= this.heigh) {
				this.y += 1;
				break;
			} else {
				isNormal = false;
				throw new MoveForwardException(String.format(
						MOVEFORWARD_WARNING_MESSAGE, id,
						Direction.N.description(), command));
			}
		case S:
			if (this.y - 1 >= 0) {
				this.y -= 1;
				break;
			} else {
				isNormal = false;
				throw new MoveForwardException(String.format(
						MOVEFORWARD_WARNING_MESSAGE, id,
						Direction.S.description(), command));
			}
		case E:
			if (this.x + 1 <= this.width) {
				this.x += 1;
				break;
			} else {
				isNormal = false;
				throw new MoveForwardException(String.format(
						MOVEFORWARD_WARNING_MESSAGE, id,
						Direction.E.description(), command));
			}
		case W:
			if (this.x - 1 >= 0) {
				this.x -= 1;
				break;
			} else {
				isNormal = false;
				throw new MoveForwardException(String.format(
						MOVEFORWARD_WARNING_MESSAGE, id,
						Direction.W.description(), command));
			}

		default:
			break;

		}

	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		if (isNormal) {

			return String.format("Rover %d: (%d %d %s) -[%s]-> (%d %d %s)\n",
					id, x0, y0, direction0, command, x, y, direction);
		} else {
			return String.format(
					"Warning: Rover %d: (%d %d %s) -[%s]-> (%d %d %s)\n", id,
					x0, y0, direction0, null, x, y, direction);
		}
	}

	public static void main(String[] args) {

		RobotRover rr = new RobotRover(1, 2, 5, 5, Direction.N, 0);
		try {
			rr.readCommand("LMLMLMLMMMMMMM");
			rr.runCommand();
		} catch (MoveForwardException e) {
			e.printStackTrace();
		}
		System.out.println(rr);

	}
}
