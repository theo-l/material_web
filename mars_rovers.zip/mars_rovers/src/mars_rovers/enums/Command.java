package mars_rovers.enums;

public enum Command {

	L("Turn Left"), R("Turn Right"), M("Move Forward");

	private final String description;
	private final static String CMD_OPTIONS = "LRM";

	private Command(String description) {
		this.description = description;
	}

	public String description() {
		return this.description;
	}

	public static boolean validateCommandLine(String commandLine) {

		for (int i = 0; i < commandLine.length(); i++) {
			if (!CMD_OPTIONS.contains(commandLine.subSequence(i, i + 1))) {
				return false;
			}
		}
		return true;

	}

}
