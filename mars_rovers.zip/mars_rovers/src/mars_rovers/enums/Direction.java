package mars_rovers.enums;

public enum Direction {

	N("North"), E("East"), S("South"), W("West");

	private final String description;
	private static final String DIRECTION_OPTIONS = "NESW";

	private Direction(String description) {
		this.description = description;
	}

	public String description() {
		return this.description;
	}

	public static boolean validateDirectionValue(String value) {
		if (DIRECTION_OPTIONS.contains(value)) {
			return true;
		}
		return false;
	}
}
